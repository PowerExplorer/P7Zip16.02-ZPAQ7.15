package net.gnu.p7zip;

import android.app.DialogFragment;
import android.view.View;
import android.view.View.OnClickListener;

public class CancelBtnListener implements OnClickListener {
	private DialogFragment frag;
	private OnFragmentInteractionListener mListener;

	public CancelBtnListener(DialogFragment frag, OnFragmentInteractionListener mListener) {
		this.frag = frag;
		this.mListener = mListener;
	}

	@Override
	public void onClick(View v) {
		mListener.onCancel(frag);
	}
}

