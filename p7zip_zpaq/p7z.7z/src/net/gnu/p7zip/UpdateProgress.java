package net.gnu.p7zip;

public interface UpdateProgress {
	public void updateProgress(String... args);
}
