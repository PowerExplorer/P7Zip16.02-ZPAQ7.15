package com.amaze.filemanager.ui.views.preference;

import android.content.Context;
import android.preference.EditTextPreference;

/**
 * Created by rpiotaix on 17/11/16.
 */

public class EditIntPreference extends EditTextPreference {
    public EditIntPreference(Context context) {
        super(context);
    }

//    public int getIntValue(){
//
//    }
//
//    public void setIntValue(int value){
//
//    }
//
//    @Override
//    public void setText(String text) {
//        setIntValue(Integer.parseInt(text));
//    }
//
//    @Override
//    public String getText() {
//        return Integer.toString(getIntValue());
//    }
}
