package jp.sblo.pandora.jota.text;

public interface JotaDocumentWatcher
{
    void onChanged(  );
}

