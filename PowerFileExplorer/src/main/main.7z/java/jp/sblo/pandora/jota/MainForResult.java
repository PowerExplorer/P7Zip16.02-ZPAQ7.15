package jp.sblo.pandora.jota;

public class MainForResult extends Main{

}


