package jp.sblo.pandora.jota;

public class LineBreak {
    static public final int CR   = 0;
    static public final int LF   = 1;
    static public final int CRLF = 2;
}
