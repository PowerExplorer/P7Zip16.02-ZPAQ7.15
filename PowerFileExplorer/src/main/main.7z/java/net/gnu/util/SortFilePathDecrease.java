//package net.gnu.util;
//
//import java.util.Comparator;
//
//public class SortFilePathDecrease implements Comparator<FileInfo> {
//	@Override
//	public int compare(FileInfo p1, FileInfo p2) {
//		return p2.path.compareToIgnoreCase(p1.path);
//	}
//}
