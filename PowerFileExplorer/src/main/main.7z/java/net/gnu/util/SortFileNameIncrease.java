//package net.gnu.util;
//
//import java.io.File;
//import java.util.Comparator;
//
//public class SortFileNameIncrease implements Comparator<File> {
//	@Override
//	public int compare(File p1, File p2) {
//		return p1.getName().compareToIgnoreCase(p2.getName());
//	}
//}
//
