//package net.gnu.util;
//import java.util.*;
//import java.io.*;
//
//public class StringSortingDecrease implements Comparator<String> {
//
//	@Override
//	public int compare(String f1, String f2) {
//		return f2.compareToIgnoreCase(f1);
//	}
//}
