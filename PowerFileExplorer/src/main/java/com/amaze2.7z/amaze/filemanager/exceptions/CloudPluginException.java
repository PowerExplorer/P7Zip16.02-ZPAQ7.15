package com.amaze.filemanager.exceptions;

/**
 * Created by vishal on 18/4/17.
 */

public class CloudPluginException extends Exception {
}
