package com.amaze.filemanager.ui.drawer;

public interface Item {
	
	boolean isSection();

}
