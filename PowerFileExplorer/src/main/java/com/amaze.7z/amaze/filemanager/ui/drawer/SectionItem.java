package com.amaze.filemanager.ui.drawer;

public class SectionItem implements Item{

	@Override
	public boolean isSection() {
		return true;
	}
}
